function panel(el, show, hide) {
    
    // remet tout les lien en ecriture normal
    for(var e of document.getElementsByTagName("a")){
        e.style.fontWeight = "normal";
    }
    
    // met en gras la page actuel
    el.style.fontWeight = "bold";
    
    //afficher la bonne page
    document.getElementById(hide).style.display = "none";
    document.getElementById(show).style.display = "block";
}

function load(){
    
    // ajoute la methode change a tout les selects
    selects = document.getElementsByTagName("select");
    for (var s of selects){
        s.addEventListener("change", function(){
            MaJoutput();
        });
    }
    
    //cache les elements a masquer
    document.getElementById("output").style.display = "none";
    document.getElementById("table").style.display = "none";
}

function fillOutputSegment(data){
    
    // ajoute le titre de la section
    tr = document.createElement("tr");
        
        td = document.createElement("td");
        td.style.fontWeight = "bold";
        td.style.height = "30px";
        tx = document.createTextNode("Consumer segment");
        td.appendChild(tx);
        tr.appendChild(td);
    
    document.getElementById("table").appendChild(tr);
    
    // rempli le tableau segment ligne par ligne
    for(i=0;i<6;i++){
        tr = document.createElement("tr");
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["Consumer.Segment"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i].Population);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["Volume.Baseline.Recontract"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["ARPU.Baseline.Recontract"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["Volume.Scenario.Recontract"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["ARPU.Scenario.Recontract"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["Volume.Baseline.NewCustomers"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["ARPU.Baseline.NewCustomers"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["Volume.Scenario.NewCustomers"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["ARPU.Scenario.NewCustomers"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        document.getElementById("table").appendChild(tr);
    }
}

function fillOutputMobile(data){
    
    // ajoute le titre de la section
    tr = document.createElement("tr");
        
        td = document.createElement("td");
        td.style.fontWeight = "bold";
        td.style.height = "30px";
        tx = document.createTextNode("Estimated mobile data usage");
        td.appendChild(tx);
        tr.appendChild(td);
    
    document.getElementById("table").appendChild(tr);
    
    // rempli le tableau ligne par ligne
    for(i=0;i<10;i++){
        tr = document.createElement("tr");
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["Estimated.mobile.data.usage"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i].Population);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["Volume.Baseline.Recontract"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["ARPU.Baseline.Recontract"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["Volume.Scenario.Recontract"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["ARPU.Scenario.Recontract"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["Volume.Baseline.NewCustomers"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["ARPU.Baseline.NewCustomers"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["Volume.Scenario.NewCustomers"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        td = document.createElement("td");
        tx = document.createTextNode(data[i]["ARPU.Scenario.NewCustomers"]);
        td.appendChild(tx);
        tr.appendChild(td);
        
        document.getElementById("table").appendChild(tr);
    } 
}

function lireJson(){
    // va chercher les données du serveur
    fetch('http://localhost:8080/json/output.json')
    .then(function(resp) {
        if (!resp.ok) {
        alert('Mauvaise réponse du réseau');
        }
    return resp.json();
    }).then(function(data) {
      
      //rempli le tableau avec les données json
      fillOutputSegment(data["consumer.Segment"]);
      fillOutputMobile(data["estimated.usage"]);
    }).catch(function(error){
        alert('Problème avec l\'opération fetch: ' + error.message);
    })
}

function MaJoutput(){
    //remplit le output avec les données json
    lireJson();
    
    //affiche les nouvelle données au lieu de l'image
    document.getElementById("image").style.display = "none";
    document.getElementById("table").style.display = "block";

}